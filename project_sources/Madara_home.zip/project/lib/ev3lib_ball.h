#ifndef EV3LIB_BALL_H
#define EV3LIB_BALL_H

#include <stdio.h>
#include "ev3c.h"
#include "lib/ev3lib_sensor.h"
#include "lib/ev3lib_motor.h"

int grab_and_check();

#endif
