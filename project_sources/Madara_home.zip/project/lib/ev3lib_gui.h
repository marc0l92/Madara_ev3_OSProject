#ifndef EV3LIB_GUI_H
#define EV3LIB_GUI_H

#include <stdio.h>
#include "ev3c.h"

#define ENABLE_DEBUG 1

void gui_motors();
void destroy_gui();

#endif
