#ifndef MY_EV3LIB_H

#include "ev3lib_gui.h"
#include "ev3lib_motor.h"
#include "ev3lib_sensor.h"
#include "ev3lib_motor_controller.h"
#include "ev3lib_bluetooth.h"
#include "ev3lib_ball.h"

#include "ev3.h"
#include "ev3_light.h"

#endif
